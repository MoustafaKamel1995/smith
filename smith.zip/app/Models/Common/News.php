<?php

namespace App\Models\Common;

use Illuminate\Database\Eloquent\Model;

class News extends Model
{
	
}
