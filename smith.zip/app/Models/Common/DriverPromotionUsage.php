<?php

namespace App\Models\Common;

use Illuminate\Database\Eloquent\Model;

class DriverPromotionUsage extends Model
{
	protected $table = 'driver_promotion_usage';
}
