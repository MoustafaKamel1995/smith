<?php


namespace App\Models\Common;

use App\Models\BaseModel;

class PaymentLog extends BaseModel
{
    protected $connection = 'common';
}
