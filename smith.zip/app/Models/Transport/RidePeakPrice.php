<?php

namespace App\Models\Transport;
use App\Models\BaseModel;

class RidePeakPrice extends BaseModel
{
    protected $connection = 'transport';
}
